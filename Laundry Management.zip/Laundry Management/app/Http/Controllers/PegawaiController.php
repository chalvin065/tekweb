<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Data;

class PegawaiController extends Controller
{
    //
    public function index() {
        $data = Data::orderBy('nama', 'asc')->paginate(10);

        return view('pegawai', compact('data'), [
            "data" => $data
        ]);
    }

    public function create() {
        return view('tambahdata');
    }

    public function store(Request $request){
        // $validate = $request->validate([
        //     "skor" => "required"
        // ]);

        Data::create([
            'nama' => $request->input('nama'),
            'jabatan' => $request->input('jabatan'),
            'notlpn' => $request->input('notlpn'),
        ]);

        return to_route('pegawai');
            
    }

    public function destroy($id) {
        Data::destroy($id);

        return to_route('pegawai');
        // return $redirect->back();
    }
    
    public function update(Request $request, $id)
    {
        $data = Data::find($id);

        if (!$data) {
            return redirect()->route('pegawai')->with('error', 'Data not found');
        }

        $data->nama = $request->nama;
        $data->jabatan = $request->jabatan;
        $data->notlpn = $request->notlpn;
        $data->save();

        return redirect()->route('pegawai')->with('success', 'Data updated successfully');
    }

    public function edit($id)
    {
        $data = Data::find($id);

        if (!$data) {
            return redirect()->route('pegawai')->with('error', 'Data not found');
        }

        return view('editdata', compact('data'));
    }


}