<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Data;

class PesananController extends Controller
{
    //
    public function index() {
        $data = Data::orderBy('nama', 'asc')->paginate(10);

        return view('pesanan', compact('data'), [
            "data" => $data
        ]);
    }

    public function create() {
        return view('tambahdata');
    }

    public function store(Request $request){
        // $validate = $request->validate([
        //     "skor" => "required"
        // ]);

        Data::create([
            'nama' => $request->input('nama'),
            'jasa' => $request->input('jasa'),
            'kuantitas' => $request->input('kuantitas'),
            'alamat' => $request->input('alamat'),
            'notlpn' => $request->input('notlpn'),
        ]);

        return to_route('data_tunggal');
            
    }

    public function destroy($id) {
        Data::destroy($id);

        return to_route('data_tunggal');
        // return $redirect->back();
    }
    
    public function update(Request $request, $id)
    {
        $data = Data::find($id);

        if (!$data) {
            return redirect()->route('data_tunggal')->with('error', 'Data not found');
        }

        $data->nama = $request->nama;
        $data->jasa = $request->jasa;
        $data->kuantitas = $request->kuantitas;
        $data->alamat = $request->alamat;
        $data->notlpn = $request->notlpn;
        $data->save();

        return redirect()->route('data_tunggal')->with('success', 'Data updated successfully');
    }

    public function edit($id)
    {
        $data = Data::find($id);

        if (!$data) {
            return redirect()->route('data_tunggal')->with('error', 'Data not found');
        }

        return view('editdata', compact('data'));
    }


}