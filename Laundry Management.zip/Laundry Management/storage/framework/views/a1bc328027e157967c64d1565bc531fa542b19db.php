<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Head content (CSS links, meta tags, etc.) -->

    <style>
        body {
            background-color: blue; /* Warna latar belakang biru */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .register-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .register-box {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .register-box input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .register-box button {
            width: 100%;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>

    <!-- Script to handle form submission and redirect -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var registerForm = document.getElementById("registerForm");

            registerForm.addEventListener("submit", function (event) {
                event.preventDefault(); // Prevents the default form submission

                // Perform any additional validation if needed

                // Redirect to the desired page (in this example, "index.html")
                window.location.href = "<?php echo e(route('index')); ?>";
            });
        });
    </script>
    <header>
    <!--Nav-->
    <nav aria-label="menu nav" class="bg-blue-800 pt-2 md:pt-1 pb-1 px-1 mt-0 h-auto fixed w-full z-20 top-0">
        <div class="flex flex-wrap items-center">
            <div class="flex flex-shrink md:w-1/3 justify-center md:justify-start text-white">
                <a href="#" >
                    <span class="text-xl pl-2"> Laundry Management</span>
                </a>
            </div>
        </div>
    </nav>
</header>
</head>

<body class="bg-blue-800 font-sans leading-normal tracking-normal mt-12">
    
    <div class="header">
        <a href="login.html">Sign In</a>
        <a href="register.html">Sign Up</a>
    </div>

    <div class="register-container">
        <div class="register-box">
            <h2 class="text-center text-xl font-bold mb-4">Register</h2>
            <form id="registerForm">
                <input type="text" placeholder="Full Name" required>
                <input type="email" placeholder="Email" required>
                <input type="password" placeholder="Password" required>
                <input type="password" placeholder="Confirm Password" required>
                <button type="submit">Register</button>
            </form>
        </div>
    </div>

    <!-- Additional content or scripts if needed -->

</body>

</html>
<?php /**PATH C:\Users\ASUS\Desktop\TEKWEB\Laundry Management\resources\views/register.blade.php ENDPATH**/ ?>