<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laundry Management</title>
    <meta name="author" content="name">
    <meta name="description" content="description here">
    <meta name="keywords" content="keywords,here">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
    <link rel="stylesheet" href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css"/> <!--Replace with your tailwind.css once created-->
    <link href="https://afeld.github.io/emoji-css/emoji.css" rel="stylesheet"> <!--Totally optional :) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.bundle.min.js" integrity="sha256-xKeoJ50pzbUGkpQxDYHD7o7hxe0LaOGeguUidbq6vis=" crossorigin="anonymous"></script>
    <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="bg-blue-800 font-sans leading-normal tracking-normal mt-12">

<header>
    <!--Nav-->
    <nav aria-label="menu nav" class="bg-blue-800 pt-2 md:pt-1 pb-1 px-1 mt-0 h-auto fixed w-full z-20 top-0">

        <div class="flex flex-wrap items-center">
            <div class="flex flex-shrink md:w-1/3 justify-center md:justify-start text-white">
                <a href="#" >
                    <span class="text-xl pl-2"> Laundry Management</span>
                </a>
            </div>
        </div>

    </nav>
</header>


<main>

    <div class="flex flex-col md:flex-row">
        <nav aria-label="alternative nav">
            <div class="bg-blue-800 shadow-xl h-20 fixed bottom-0 mt-12 md:relative md:h-screen z-10 w-full md:w-48 content-center">

                <div class="md:mt-12 md:w-48 md:fixed md:left-0 md:top-0 content-center md:content-start text-left justify-between">
                    <ul class="list-reset flex flex-row md:flex-col pt-3 md:py-3 px-1 md:px-2 text-center md:text-left">
                        <li class="mr-3 flex-1">
                            <a href="<?php echo e(route('index')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-white no-underline hover:text-white border-b-2 border-blue-800 hover:border-blue-600">
                                <i class="fas fa-table pr-0 md:pr-3"></i><span class="pb-1 md:pb-0 text-xs md:text-base text-gray-400 md:text-gray-200 block md:inline-block">Home</span>
                            </a>
                        </li>
                        <li class="mr-3 flex-1">
                            <a href="<?php echo e(route('data_tunggal')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-white no-underline hover:text-white border-b-2 border-blue-600">
                                <i class="fas fa-table pr-0 md:pr-3 text-blue-600"></i><span class="pb-1 md:pb-0 text-xs md:text-base text-white md:text-white block md:inline-block">Pesanan</span>
                            </a>
                        </li>
                        <li class="mr-3 flex-1">
                            <a href="<?php echo e(route('pegawai')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-white no-underline hover:text-white border-b-2 border-blue-600">
                                <i class="fas fa-table pr-0 md:pr-3 text-blue-600"></i><span class="pb-1 md:pb-0 text-xs md:text-base text-white md:text-white block md:inline-block">Pegawai</span>
                            </a>
                        </li>
                    </ul>
                </div>


            </div>
        </nav>
        <section class="w-full overflow-x-hidden border-t flex flex-col">
            <div id="main" class="main-content flex-1 bg-blue-100 mt-12 md:mt-2 pb-24 md:pb-5">
            <div class="bg-blue-800 pt-3">
                    <div class="rounded-tl-3xl bg-gradient-to-r from-blue-900 to-blue-800 p-4 shadow text-2xl text-white">
                        <h1 class="font-bold pl-2">Pegawai</h1>
                    </div>
                </div>

                <div class="px-7 py-3">

                <div class="pb-3 ml-auto">
                    <button class="w-1/5 text-white bg-blue-800 font-semibold py-2 rounded-tl-lg rounded-br-lg rounded-bl-lg rounded-tr-lg shadow-lg hover:shadow-xl hover:bg-gray-600 flex items-center justify-center">
                    <i class="fas fa-plus mr-3"></i> 
                    <a href="<?php echo e(route('pegawai.create')); ?>">Tambah Pegawai</a>
                    </button>
                </div>

                    <table class="table-auto w-full">
                        <thead>
                            <tr>
                                <th class="w-1/4 text-center px-4 py-2 bg-gray-800 text-white">No</th>
                                <th class="w-1/4 text-center px-4 py-2 bg-gray-800 text-white">Nama</th>
                                <th class="w-1/4 text-center px-4 py-2 bg-gray-800 text-white">Jabatan</th>
                                <th class="w-1/4 text-center px-4 py-2 bg-gray-800 text-white">No. Telepon</th>
                                <th colspan="2" class="w-1/4 text-center px-4 py-2 bg-gray-800 text-white">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $i = ($data->currentPage() - 1) * $data->perPage();
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border border-gray-300 w-1/4 text-center px-4 py-2"> <?php echo e(++$i); ?> </td>
                                <td class="border border-gray-300 w-1/4 text-center px-4 py-2"> <?php echo e($item->nama); ?> </td>
                                <td class="border border-gray-300 w-1/4 text-center px-4 py-2"> <?php echo e($item->jabatan); ?> </td>
                                <td class="border border-gray-300 w-1/4 text-center px-4 py-2"> <?php echo e($item->notlpn); ?> </td>
                                <td class="border border-gray-300 w-1/8 text-center px-4 py-2">
                                    <a href="<?php echo e(route('pegawai.edit', $item->id)); ?>">Edit</a>
                                </td>
                                <td class="border border-gray-300 w-1/8 text-center px-4 py-2">
                                    <form action="<?php echo e(route('pegawai.destroy', ['id'=>$item->id])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
                <div class="flex items-center justify-end">
                    <?php echo e($data->links()); ?>

                </div>


            </div>
        </section>
    </div>
</main>




<script>
    /*Toggle dropdown list*/
    function toggleDD(myDropMenu) {
        document.getElementById(myDropMenu).classList.toggle("invisible");
    }
    /*Filter dropdown options*/
    function filterDD(myDropMenu, myDropMenuSearch) {
        var input, filter, ul, li, a, i;
        input = document.getElementById(myDropMenuSearch);
        filter = input.value.toUpperCase();
        div = document.getElementById(myDropMenu);
        a = div.getElementsByTagName("a");
        for (i = 0; i < a.length; i++) {
            if (a[i].innerHTML.toUpperCase().indexOf(filter) > -1) {
                a[i].style.display = "";
            } else {
                a[i].style.display = "none";
            }
        }
    }
    // Close the dropdown menu if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.drop-button') && !event.target.matches('.drop-search')) {
            var dropdowns = document.getElementsByClassName("dropdownlist");
            for (var i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (!openDropdown.classList.contains('invisible')) {
                    openDropdown.classList.add('invisible');
                }
            }
        }
    }
</script>


</body>

</html>
<?php /**PATH C:\Users\ASUS\Desktop\TEKWEB\statistik\resources\views/pegawai.blade.php ENDPATH**/ ?>