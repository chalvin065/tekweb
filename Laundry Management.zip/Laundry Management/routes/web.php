<?php

use Illuminate\Support\Facades\Route;
use App\Models\Data;
use Illuminate\Http\Request;
use App\Http\Controllers\PesananController;
use App\Http\Controllers\PegawaiController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/login', function () {
    return view('login');
});
Route::get('/register', function () {
    return view('register');
});

Route::get('/data_tunggal', [PesananController::class, 'index'])->name("data_tunggal");
Route::get('/data_tunggal/create', [PesananController::class, 'create'])->name("data_tunggal.create");
Route::post('/data_tunggal/store', [PesananController::class, 'store'])->name("data_tunggal.store");
Route::post('/data_tunggal/delete/{id}', [PesananController::class, 'destroy'])->name("data_tunggal.destroy");
Route::get('/data_tunggal/edit/{id}', [PesananController::class, 'edit'])->name("data_tunggal.edit");
Route::put('/data_tunggal/update/{id}', [PesananController::class, 'update'])->name("data_tunggal.update");

Route::get('/pegawai', [PegawaiController::class, 'index'])->name("pegawai");
Route::get('/pegawai/create', [PegawaiController::class, 'create'])->name("pegawai.create");
Route::post('/pegawai/store', [PegawaiController::class, 'store'])->name("pegawai.store");
Route::post('/pegawai/delete/{id}', [PegawaiController::class, 'destroy'])->name("pegawai.destroy");
Route::get('/pegawai/edit/{id}', [PegawaiController::class, 'edit'])->name("pegawai.edit");
Route::put('/pegawai/update/{id}', [PegawaiController::class, 'update'])->name("pegawai.update");




Route::get('/index', function () {
    return view('index');
})->name("index");
